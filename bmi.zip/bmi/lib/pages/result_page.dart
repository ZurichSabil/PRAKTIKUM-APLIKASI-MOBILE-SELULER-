import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {
  final String nama;
  final double bmi;
  final String gender;
  final int usia;
  final int berat;
  final double tinggi;

  const ResultPage({
    super.key,
    required this.nama,
    required this.bmi,
    required this.gender,
    required this.usia,
    required this.berat,
    required this.tinggi,
  });

  String getStatusBMI() {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal';
    if (bmi < 30) return 'Overweight';
    return 'Obesity';
  }

  Color getStatusColor() {
    if (bmi < 18.5) return Colors.blue;
    if (bmi < 25) return Colors.green;
    if (bmi < 30) return Colors.orange;
    return Colors.red;
  }

  String getAdvice() {
    if (bmi < 18.5) {
      return 'Coba tingkatkan asupan nutrisi dan konsumsi makanan berkalori sehat seperti kacang, alpukat, dan protein. Jangan lupa olahraga ringan untuk membentuk massa otot.';
    }
    if (bmi < 25) {
      return 'Bagus! Pertahankan pola makan seimbang dengan gizi lengkap. Lanjutkan olahraga rutin 3-4 kali seminggu untuk menjaga kebugaran.';
    }
    if (bmi < 30) {
      return 'Coba kurangi makanan tinggi gula dan lemak jenuh. Perbanyak sayur, buah, dan olahraga kardio seperti jalan cepat atau bersepeda.';
    }
    return 'Segera konsultasikan dengan dokter atau ahli gizi. Mulai pola makan sehat, perbanyak aktivitas fisik, dan hindari makanan olahan.';
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Color(0xFF1A73E8);
    final Color accentColor = Color(0xFFE8F0FE);

    return Scaffold(
      backgroundColor: accentColor,
      appBar: AppBar(
        title: Text("HASIL BMI"),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              // Kartu Hasil Utama
              Container(
                padding: EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      nama,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '$gender • $usia tahun',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    Divider(height: 30),
                    Text(
                      bmi.toStringAsFixed(2),
                      style: TextStyle(
                        fontSize: 64,
                        fontWeight: FontWeight.bold,
                        color: getStatusColor(),
                      ),
                    ),
                    SizedBox(height: 8),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: getStatusColor().withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        getStatusBMI().toUpperCase(),
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: getStatusColor(),
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Kartu Detail Data (TANPA IKON)
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    _buildInfoRow('Berat Badan', '$berat kg'),
                    _buildInfoRow('Tinggi Badan', '${tinggi.toInt()} cm'),
                    _buildInfoRow('Usia', '$usia tahun'),
                    _buildInfoRow('Jenis Kelamin', gender),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Kartu Saran / Pesan
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: getStatusColor().withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: getStatusColor().withOpacity(0.3),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Saran untuk Anda',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: getStatusColor(),
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      getAdvice(),
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.5,
                        color: Colors.grey.shade800,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Kartu Rentang BMI
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    _buildBMIRange(
                      'Underweight',
                      '< 18.5',
                      bmi < 18.5,
                      Colors.blue,
                    ),
                    _buildBMIRange(
                      'Normal',
                      '18.5 - 24.9',
                      bmi >= 18.5 && bmi < 25,
                      Colors.green,
                    ),
                    _buildBMIRange(
                      'Overweight',
                      '25 - 29.9',
                      bmi >= 25 && bmi < 30,
                      Colors.orange,
                    ),
                    _buildBMIRange(
                      'Obesity',
                      '30 - 40',
                      bmi >= 30,
                      Colors.red,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Tombol Kembali
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: primaryColor,
                  ),
                  width: double.infinity,
                  height: 50,
                  child: Center(
                    child: Text(
                      "HITUNG ULANG",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ========== INI YANG DIUBAH: HAPUS IKON ==========
  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          // IKON SUDAH DIHAPUS!
          SizedBox(width: 0), // Tidak ada ikon lagi
          Text(
            label,
            style: TextStyle(fontSize: 16, color: Colors.grey.shade700),
          ),
          Spacer(),
          Text(
            value,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildBMIRange(String title, String range, bool isActive, Color color) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: isActive ? color.withOpacity(0.1) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isActive ? color : Colors.grey.shade300,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isActive ? Icons.check_circle : Icons.circle_outlined,
            color: isActive ? color : Colors.grey.shade400,
            size: 20,
          ),
          SizedBox(width: 12),
          Text(
            title,
            style: TextStyle(
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              color: isActive ? color : Colors.grey.shade600,
            ),
          ),
          Spacer(),
          Text(
            range,
            style: TextStyle(
              color: isActive ? color : Colors.grey.shade500,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}